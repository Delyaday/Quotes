﻿using Microsoft.Win32;

using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Quotes
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var exeFileDirectory = AppDomain.CurrentDomain.BaseDirectory;
            var imagesDirectory = new DirectoryInfo(Path.Combine(exeFileDirectory, "Images"));

            var imageFiles = imagesDirectory.EnumerateFiles("*.jpg");

            var selectedFile = imageFiles.ElementAt(new Random().Next(0, imageFiles.Count()));

            image.Source = new BitmapImage(new Uri(selectedFile.FullName, UriKind.Absolute));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "*.jpg|*.jpg";
            if (saveFileDialog.ShowDialog() == true)
            {
                BitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(image.Source as BitmapImage));

                using (var fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                {
                    encoder.Save(fileStream);
                }
            }

        }
    }
}
